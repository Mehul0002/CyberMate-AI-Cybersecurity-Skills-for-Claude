# Installation

## Claude Code

### Personal installation
Create the following directory if it does not exist:

- Windows: `%USERPROFILE%\.claude\skills\`
- macOS/Linux: `~/.claude/skills/`

Copy each folder inside this repository's `skills/` directory into that location. Example:

```text
~/.claude/skills/
  recon/SKILL.md
  web-audit/SKILL.md
  vuln-report/SKILL.md
  log-analyze/SKILL.md
  soc-investigate/SKILL.md
  incident-response/SKILL.md
```

### Per-project installation
Copy `skills/` to your project's `.claude/skills/` directory, so the layout is `.claude/skills/recon/SKILL.md`, etc.

Restart Claude Code if the skills do not appear. Availability can vary by Claude Code version and configuration.

## Claude Desktop / Claude.ai

This repository targets Claude Code slash commands. Claude Desktop and Claude.ai custom Skills may use a different import and invocation flow. Do not assume `/recon` behaves identically in every Claude product. Follow the current official Anthropic documentation for the product you use.

## Optional log script

Python 3.10 or newer; no third-party packages:

```bash
python scripts/log_summary.py path/to/logfile.csv
```

Use only files you are allowed to analyze. The script prints summary statistics and does not upload data.
