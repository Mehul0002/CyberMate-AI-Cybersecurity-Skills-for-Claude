# Usage examples

## Reconnaissance
```text
/recon example.com
```
Start with scope and authorization. This skill favors passive/public information and does not direct automatic intrusive scanning.

## Web audit
```text
/web-audit https://your-owned-lab.example
```
Provide the app scope, test account constraints, allowed methods, and test window. Review configuration and supplied evidence first.

## Vulnerability report
```text
/vuln-report
```
Paste findings or point Claude to a file in your current workspace. Ask it to separate verified facts from hypotheses.

## Log analysis
```text
/log-analyze ./sample-auth.csv
```
Provide the file path and time zone if known. Redact tokens, passwords, session IDs, and personal information first.

## SOC triage
```text
/soc-investigate
```
Paste the alert, affected asset, timestamps, and known context. Avoid exposing secrets.

## Incident response
```text
/incident-response
```
Describe the suspected incident and constraints. Preserve evidence; follow your organization's escalation policy.
