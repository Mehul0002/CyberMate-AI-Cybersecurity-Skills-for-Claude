#!/usr/bin/env python3
"""Summarize a local CSV file without network access (Python standard library only)."""
import argparse
import csv
from collections import Counter
from pathlib import Path
import sys

def main():
    parser = argparse.ArgumentParser(description="Basic local CSV log summary; no data is uploaded.")
    parser.add_argument("file", help="Path to a CSV file you are authorized to analyze")
    parser.add_argument("--max-rows", type=int, default=100000, help="Maximum rows to read (default: 100000)")
    args = parser.parse_args()
    path = Path(args.file).expanduser()
    if not path.is_file():
        print(f"Error: file not found: {path}", file=sys.stderr)
        return 2
    if args.max_rows < 1:
        print("Error: --max-rows must be at least 1", file=sys.stderr)
        return 2

    rows = 0
    columns = Counter()
    values = {}
    try:
        with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                print("Error: CSV has no header row.", file=sys.stderr)
                return 2
            print("Columns:", ", ".join(reader.fieldnames))
            for row in reader:
                rows += 1
                for key, value in row.items():
                    if key is None:
                        continue
                    columns[key] += 1
                    val = (value or "").strip()
                    if val:
                        counter = values.setdefault(key, Counter())
                        counter[val[:120]] += 1
                if rows >= args.max_rows:
                    break
    except OSError as exc:
        print(f"Error reading file: {exc}", file=sys.stderr)
        return 2

    print(f"Rows summarized: {rows}")
    print("Non-empty values per column:")
    for key, count in columns.items():
        print(f"  {key}: {count}")
    for key, counter in values.items():
        lowered = key.lower()
        if any(token in lowered for token in ("status", "event", "action", "type", "result")):
            print(f"\\nMost common values in {key}:")
            for value, count in counter.most_common(10):
                # Avoid printing obvious secrets or long identifiers.
                if any(secret in value.lower() for secret in ("password=", "token=", "authorization:")):
                    value = "[REDACTED]"
                print(f"  {count:>6}  {value}")
    print("\\nNote: This is a basic summary, not an automated threat verdict.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
