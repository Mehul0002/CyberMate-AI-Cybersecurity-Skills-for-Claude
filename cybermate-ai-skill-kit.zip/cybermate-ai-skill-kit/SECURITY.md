# Security Policy

## Scope and responsible use

CyberMate AI is a set of defensive workflow instructions and report templates. Use it only on systems you own or have explicit written permission to assess. Do not use it to bypass access controls, steal credentials, persist on systems, disrupt services, or access data outside the approved scope.

## Reporting a problem

Please open a GitHub issue for non-sensitive documentation or workflow bugs. Do not publish credentials, private logs, personal data, or exploitable details about a third-party system in a public issue. For sensitive reports, contact the repository maintainer privately using the contact method listed on the repository profile.
