# Contributing

1. Open an issue describing the proposed change.
2. Keep workflows defensive, scoped, and evidence-based.
3. Never add API keys, credentials, private logs, or personal information.
4. Document any optional dependencies and provide a safe test case.
5. Test scripts against synthetic/sample data before submitting a pull request.
