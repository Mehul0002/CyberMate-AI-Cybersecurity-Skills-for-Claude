# Reconnaissance Report

- **Target:** 
- **Authorization / ticket:** 
- **Approved scope:** 
- **Assessment window (timezone):** 
- **Analyst:** 
- **Date:** 

## Executive summary
TODO

## Scope and exclusions
TODO

## Passive/public observations
| Observation | Source | Timestamp | Confidence | Notes |
|---|---|---|---|---|

## Items requiring validation
| Item | Why it matters | Safe validation method | Priority |
|---|---|---|---|

## Limitations
TODO

## Recommendations
TODO
