---
name: recon
description: Plan and document passive-first reconnaissance for an explicitly authorized domain or asset. Use when the user invokes /recon or requests scoped asset discovery.
argument-hint: "<domain or asset>"
---

# Recon Assistant

The user's arguments are: `$ARGUMENTS`

## Required safety gate
1. Identify the target from `$ARGUMENTS`. If missing, ask for it.
2. Before any live testing, ask the user to confirm they own the target or have explicit written authorization. Ask for the exact in-scope domains/IPs, exclusions, and test window. Do not infer permission from a public domain name.
3. If authorization/scope is not confirmed, provide only a general plan or use a fictional/local lab example. Do not initiate live scanning.
4. Never attempt login bypass, credential attacks, exploitation, stealth, persistence, denial of service, or access to private data.

## Workflow
1. Normalize the supplied domain and flag ambiguity (subdomains, redirects, third-party hosting).
2. Create a scope table: asset, owner/authorization, included/excluded, notes.
3. Start with passive-first collection using information already supplied by the user or publicly available records. Suggested categories: DNS records, certificate transparency, public registration data where available, and search-engine-indexed pages. Do not claim you queried a source unless a tool actually did so.
4. If tools/network access are unavailable, give the user safe commands or manual steps as suggestions, not as completed actions. Explain what each command does before proposing it.
5. Recommend active checks only when explicitly in scope; describe rate limits and impact. Ask for confirmation before running any command that contacts the target.
6. Separate observed facts, user-supplied claims, and hypotheses. Include source and timestamp for each observation when available.
7. Produce a report using `../../templates/recon-report.md` when accessible, otherwise reproduce its headings.

## Output
- Scope and authorization status
- Passive observations with sources
- Unknowns and confidence
- Safe next steps
- Limitations
- Markdown report

Do not fabricate findings or claim scans were completed if they were not.
