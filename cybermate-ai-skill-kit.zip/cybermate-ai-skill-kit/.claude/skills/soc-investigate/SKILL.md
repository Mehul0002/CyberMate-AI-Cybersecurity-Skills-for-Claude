---
name: soc-investigate
description: Triage a security alert in a defensive SOC workflow using user-provided alert details and evidence. Use for /soc-investigate.
---

# SOC Alert Triage

Ask for alert source, timestamp/timezone, affected asset, user/account (redacted where possible), severity, and relevant telemetry. Do not request passwords, tokens, or unnecessary personal data.

## Workflow
1. Restate the alert and known facts.
2. Separate evidence, assumptions, and unknowns.
3. Assess likely false-positive explanations and competing hypotheses.
4. Recommend safe evidence collection and correlation across authorized logs (identity, endpoint, DNS, proxy, firewall, cloud audit).
5. Propose severity with rationale and confidence; do not attribute an attacker without evidence.
6. Give containment options with operational tradeoffs. For disruptive actions, require human approval and follow the organization's playbook.
7. Create a timeline and escalation summary.

Do not execute containment, disable accounts, isolate endpoints, delete files, or change production systems. Provide recommendations for an authorized operator to approve.
