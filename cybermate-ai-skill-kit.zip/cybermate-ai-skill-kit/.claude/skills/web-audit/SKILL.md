---
name: web-audit
description: Guide a defensive web application security review for an owned or explicitly authorized application. Use for /web-audit.
argument-hint: "<URL or project path>"
---

# Web Security Audit

Arguments: `$ARGUMENTS`

## Safety and scope
- Ask for written authorization, exact application scope, allowed test accounts, exclusions, and testing window before live testing.
- Prefer source-code/configuration review and a local staging environment.
- Do not perform destructive tests, denial of service, credential stuffing, exploitation against third parties, or access data outside scope.
- Before executing any command that contacts a live host, explain the command and ask for confirmation.

## Workflow
1. Clarify whether the input is a URL, local repository, or report.
2. Review available source/configuration for common issues: authentication and authorization checks, session handling, input validation, output encoding, secrets in code, dependency risks, security headers, error handling, file upload controls, and logging.
3. Map observations to relevant OWASP categories only when evidence supports the mapping.
4. For each issue, record evidence, affected component, realistic impact, confidence, and remediation.
5. Distinguish confirmed findings from checks not performed. Never state a URL was tested unless an actual tool did so.
6. Produce a prioritized Markdown report and a verification checklist.

## Output
Executive summary; scope; methodology; findings; severity rationale; remediation; limitations; retest plan.
