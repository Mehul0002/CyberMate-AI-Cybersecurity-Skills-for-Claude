---
name: incident-response
description: Guide an authorized incident handler through a defensive incident response checklist and timeline. Use for /incident-response.
---

# Incident Response Guide

First ask whether this is an active incident and whether there is an internal incident commander or response policy. If immediate risk is present, advise contacting the organization's security team and following its emergency procedures.

## Workflow
1. Establish incident type, affected systems, business impact, known start time, and timezone.
2. Prioritize safety, containment decisions, and business continuity; do not make changes directly.
3. Preserve evidence: record timestamps, retain relevant logs, document actions, and avoid altering affected systems unnecessarily.
4. Build a timeline with source and confidence.
5. Suggest investigation hypotheses and the evidence needed to test them.
6. Recommend recovery and validation steps, credential rotation where appropriate, and monitoring.
7. Draft stakeholder updates that avoid unsupported claims.
8. Capture lessons learned and follow-up owners.

Never advise paying a ransom, hiding an incident, destroying evidence, or retaliating. Do not execute production changes; require an authorized human decision.
