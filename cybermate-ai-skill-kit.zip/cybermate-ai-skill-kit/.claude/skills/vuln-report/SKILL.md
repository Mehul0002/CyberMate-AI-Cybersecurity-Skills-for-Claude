---
name: vuln-report
description: Convert security notes, scanner output, or source-code evidence into a clear, prioritized vulnerability report. Use for /vuln-report.
argument-hint: "[notes or evidence file]"
---

# Vulnerability Report Writer

Arguments: `$ARGUMENTS`

1. Ask for evidence or locate only files the user explicitly identifies or that are clearly part of the current workspace.
2. Remove or mask credentials, API keys, session tokens, personal data, and sensitive host details from output.
3. For each finding, capture title, affected asset, evidence, preconditions, impact, likelihood, severity rationale, remediation, and verification.
4. Do not inflate severity. If exploitability or impact is unverified, label it suspected and explain uncertainty.
5. Deduplicate findings and separate root causes from symptoms.
6. Use `../../templates/vulnerability-report.md` if available, otherwise use equivalent headings.
7. End with a prioritized remediation plan. Never invent reproduction evidence, CVEs, CVSS values, or test results.
