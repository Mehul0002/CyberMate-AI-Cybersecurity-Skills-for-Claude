# CyberMate AI — Claude Code Security Skills

A GitHub-ready collection of defensive cybersecurity skills for Claude Code. Each skill provides a guided workflow, safety checks, and report templates.

> **Safety first:** Use only on systems you own or are explicitly authorized to assess. These skills are workflow instructions, not a guarantee that Claude can run scanners or access the network. Tool availability depends on your environment and permissions.

## Included skills

- `/recon <domain>` — authorization/scope check, passive-first reconnaissance planning, and a structured report.
- `/web-audit <url>` — safe web application review planning and evidence-based findings.
- `/vuln-report` — turn supplied notes/evidence into a prioritized vulnerability report.
- `/log-analyze <file>` — analyze a user-provided log/CSV file for suspicious patterns.
- `/soc-investigate` — guided triage for a security alert.
- `/incident-response` — structured incident response checklist and timeline.

## Install

### Option A — Use directly after cloning (project skills)

Clone this repository, open it in Claude Code, and the commands should be available from the included `.claude/skills/` directory. If Claude Code was already open before you created the `.claude/skills/` directory, restart the session or reload skills.

### Option B — Personal skills (available across your Claude Code projects)

Copy the `skills/` folder contents into:

- Windows: `%USERPROFILE%\\.claude\\skills\\`
- macOS/Linux: `~/.claude/skills/`

Each skill must be a folder containing `SKILL.md`, e.g. `~/.claude/skills/recon/SKILL.md`.

### Option C — Project skills (only in one repository)

Copy the `skills/` folder into your project as `.claude/skills/`. Example:

```text
your-project/
  .claude/
    skills/
      recon/SKILL.md
      web-audit/SKILL.md
```

The resulting commands are available as `/recon`, `/web-audit`, etc. In Claude Code, try:

```text
/recon example.com
```

Claude Code may ask for clarification before proceeding. For any live assessment, confirm written authorization and scope first.

## What this kit does / does not do

- It provides structured instructions and templates to guide Claude.
- It does **not** bundle exploit code, credentials, API keys, commercial tools, or hidden dependencies.
- It does **not** automatically install tools or guarantee live scanning. If a skill asks for a command, Claude should first explain what it intends to run and obtain confirmation when the action could affect a system.
- For a safe first test, use a fictional domain such as `example.com`, a local lab, or a log file you own.

## Dependencies

No Python packages are required for the core skills. Optional local analysis scripts use Python 3.10+ and the standard library only.

## Repository layout

```text
cybermate-ai-skill-kit/
├── README.md
├── LICENSE
├── SECURITY.md
├── CONTRIBUTING.md
├── .gitignore
├── .claude/skills/       # Ready to use when this repo is opened in Claude Code
│   ├── recon/SKILL.md
│   └── ...
├── skills/                # Copyable distribution source
│   ├── recon/SKILL.md
│   ├── web-audit/SKILL.md
│   ├── vuln-report/SKILL.md
│   ├── log-analyze/SKILL.md
│   ├── soc-investigate/SKILL.md
│   └── incident-response/SKILL.md
├── templates/
│   ├── recon-report.md
│   ├── vulnerability-report.md
│   └── incident-timeline.csv
├── scripts/
│   └── log_summary.py
└── docs/
    ├── INSTALLATION.md
    └── USAGE.md
```

## License

MIT — see `LICENSE`.
